use std::collections::HashMap;
use std::io;
use std::convert::TryInto;

fn main() 
{
	let mut n=String::new();
	let mut name=String::new();
	let mut id=String::new();
	let mut no=String::new();
    let mut sal=String::new();
	let mut mail_id=String::new();
	let mut v_name:Vec<String>=Vec::new();
	let mut v_id:Vec<String>=Vec::new();
	let mut v_no:Vec<String>=Vec::new();
    let mut v_sal:Vec<String>=Vec::new();
	let mut v_email:Vec<String>=Vec::new();
	let mut c=1;
	let mut choice=String::new();
	let mut ch=String::new();

	println!("----------How many Employee details you want to store------------");

	io::stdin().read_line(&mut n).expect("Fail");
	let n:u32=n.trim().parse().expect("Fail");
	
	while c<=n
    {
		name.clear();
		id.clear();
		no.clear();
        sal.clear();
		println!("-----------To add employee's deatils please enter name, emp_id, contact no, salary----------");
		
        println!("Enter name:");
		io::stdin().read_line(&mut name).expect("Fail");
		let name:String=name.trim().parse().expect("Failed");

		println!("Enter id:");
		io::stdin().read_line(&mut id).expect("Fail");
		let id:String=id.trim().parse().expect("Failed");

		if v_id.contains(& id)
		{
		
			println!(".....Employee ID is already present, Please enter unique id.....");
			break;
		}
		else
		{
		println!("Enter contact no:");
        io::stdin().read_line(&mut no).expect("Fail");
		let no:String=no.trim().parse().expect("Failed");

		if no.len()==10
		{
			
		}
		else
		{
			println!("---Contact no Invalid, Please enter valid contact no---");
			break;		
		}
		println!("Enter Email Id:");
        
        io::stdin().read_line(&mut mail_id).expect("Fail");
        let mail_id:String=mail_id.trim().parse().expect("Failed");

		println!("Enter Salary:");
        io::stdin().read_line(&mut sal).expect("Fail");
		let sal:String=sal.trim().parse().expect("Failed");
		
		v_name.push(name);
		v_id.push(id);
		v_no.push(no);
		v_email.push(mail_id);
        v_sal.push(sal);
		c+=1;
	}
	println!("Name: {:?}\nId: {:?}\nContact no: {:?}\nEmail_ID: {:?}\nSalary: {:?}",v_name,v_id,v_no,v_email,v_sal);
	}

	let name:HashMap<&String,&String>=v_id.iter()
	.zip(v_name.iter()).collect();
	
	let emp_id:HashMap<&String,&String>=v_id.iter()
	.zip(v_id.iter()).collect();

    let contact:HashMap<&String,&String>=v_id.iter()
	.zip(v_no.iter()).collect();

	let email_id:HashMap<&String,&String>=v_id.iter()
	.zip(v_email.iter()).collect();

    let salary:HashMap<&String,&String>=v_id.iter()
	.zip(v_sal.iter()).collect();

	println!("------------------------In HashMap--------------------------------");
	println!("{:?}\n{:?}\n{:?}\n{:?}\n{:?}",name,emp_id,contact,email_id,salary);	

	println!("-------------Which Emp_ID you want to Search----------------------");
	io::stdin().read_line(&mut choice).expect("Fail");
	let choice:String=choice.trim().parse().expect("Fail");
	
	if v_id.contains(&choice)
	{

	}
	else
	{
		println!("------------No such record present-----------");	
	}

	n_show(name,&choice);
	id_show(emp_id,&choice);
	no_show(contact,&choice);
	mail_show(email_id,&choice);
    sal_show(salary,&choice);

	println!("-----------Which records you want to detele---------");
	io::stdin().read_line(&mut ch).expect("Fail");
	let ch:u32=ch.trim().parse().expect("Fail");

	let s=ch.to_string();
	if v_id.contains(&s)
	{
		 let s= v_name.remove(ch.try_into().unwrap());
		 let s= v_id.remove(ch.try_into().unwrap());
		 let s= v_no.remove(ch.try_into().unwrap());
		 let s= v_email.remove(ch.try_into().unwrap());
		let s= v_sal.remove(ch.try_into().unwrap());
	}

	println!("...........After deleting record, vector is.......");
	println!("Name: {:?}\nId: {:?}\nContact no: {:?}\nEmail_ID: {:?}\nSalary: {:?}",v_name,v_id,v_no,v_email,v_sal);

}
fn n_show(name:HashMap<&String,&String>,choice:&String)
{
		for (a,b) in name
		{
			if a==choice 
			{
				println!("Name: {} ",b);
			}
		}
}
fn id_show(emp_id:HashMap<&String,&String>,choice:&String)
{
		for (c,d) in emp_id
		{
			if c==choice 
			{
				println!("Emp_id: {} ",d);
			}
		}
}
fn no_show(contact:HashMap<&String,&String>,choice:&String)
{
		for (e,f) in contact
		{
			if e==choice 
			{
				println!("Contact: {} ",f);
			}
		}
}
fn mail_show(email_id:HashMap<&String,&String>,choice:&String)
{
		for (g,h) in email_id
		{
			if g==choice 
			{
				println!("Email id: {} ",h);
			}
		}
}
fn sal_show(salary:HashMap<&String,&String>,choice:&String)
{
    for (i,j) in salary
	{
        if i==choice 
		{
            println!("Salary: {} ",j);
        }
    }
}
